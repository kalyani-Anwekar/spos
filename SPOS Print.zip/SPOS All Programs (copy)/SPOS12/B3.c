/*

Implement UNIX system calls like ps, fork, join, exec family, and wait for process
management (use shell script/ Java/ C programming).

C/C++ Program to Parent creating the child process by use of fork.
*/

#include<stdio.h>
#include<unistd.h>
int main()
{
	int pid;

	pid=fork();

	if(pid==0)
	{
		printf("\n After fork");
		printf("\n The new child process created by fork system call %d\n", getpid());
	}
	else 
	{
		printf("\n Befor fork");

		printf("\n The parent process id is :- %d ", getppid());
		printf("\n parent excuted successfully\n");

	}

	return 0;

}


/*///////////////////////   OUTPUT   ////////////////////////////////////


kp@kp-HP-Pavilion-Notebook:~/Documents/SPOS manual and materials/SPOS/fwdsposmaterial$ gcc B3.c 
kp@kp-HP-Pavilion-Notebook:~/Documents/SPOS manual and materials/SPOS/fwdsposmaterial$ ./a.out

 Befor fork
 The parent process id is :- 3639 
 parent excuted successfully

 After fork
 The new child process created by fork system call 3659


/*///////////////////////////////////////////////////////////////////////
