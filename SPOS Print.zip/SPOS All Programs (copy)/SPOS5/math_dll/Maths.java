package math_dll;
public class Maths
{
	public long abs(long value) 
	{
		if (value < 0) 
		{
			return -value;
		}
		else 
		{
			return value;  
		}
	}

	public float square (float a)
	{
		return a*a;
	}
	public float sin (float deg)
	{
		while (deg >= 360) 
			deg = deg - 360;

		while (deg < 0) 
			deg = deg + 360;

		if (deg > 180) 
		{
			deg = deg - 180;
		}
		
		float ret = (float)(4*deg*(180-deg))/(40500-(deg*(180-deg)));
		return ret;
	}
	
	public float cos(float x)
	{
		float b=90-x;	
		b=sin(b);
		return b;
	}
	public float tan(float x)
	{	
		float b=sin(x)/cos(x);
		return b;
	}

}
